
<div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>Search Pantheon:</h2>
                        <form action="search.php" method="post">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control">
                            <span class="input-group-btn">
                                <button name="submit" class="btn btn-default" type="submit"><p class="text-light">Search</p></button>
                            </span>
                        </div>
                        </form>
					</div>
				</div>
			</div>   