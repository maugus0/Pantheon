<!-- Header Area -->
<header id="site-header" class="site-header">
		<!-- Header -->
		<div class="header-bottom bg-light">
			<div class="container bg-light">
				<div class="row bg-light">
					<div class="col-lg-2 col-md-2 col-12">
						<!-- Logo -->
						<div class="logo">
							<a href="index.php"><img width="200" class="img-responsive" style="margin-bottom: 20px;" src="img/logo.png" alt="#"></a>
						</div>
						<!-- End Logo -->
					</div>
				<div class="col-lg-10 col-md-10 col-12">
					<!-- Main Menu -->
					<div class="main-menu" style="margin-top: 10px;">
						<nav class="navigation ">
							<ul class="nav menu">
							<li></li>
							</ul>
						</nav>
					</div>
					<!--/ End Main Menu -->
					<a href="login.php" class="button">Login</a>
				</div>
				</div>
			</div>
		</div>
		<!--/ End Header Bottom -->
    </header>
	<!--/ End Header Area -->