<div class="wrapper d-flex align-items-stretch">
<nav id="sidebar" class="active">
<h1><a href="index.php" class="logo">P.</a></h1>
<ul class="list-unstyled components mb-5">
<li class="active">
<a href="index.php"><span class="fa fa-bar-chart-o"></span> Stats</a>
</li>
<li>
<a href="javascript:;" data-toggle="collapse" data-target="#posts"><span class="fa fa-sticky-note"></span> Posts</a>
                        <ul id="posts" class="collapse">
                            <li>
                                <a href="posts.php">View All Posts</a>
                            </li>
                            <li>
                                <a href="posts.php?source=add_posts">Add Posts</a>
                            </li>
                        </ul>
</li>
<li>
<a href="profile.php?source=update_profile"><span class="fa fa-user-circle"></span> Profile</a>
</li>
</ul>

<div class="footer">
<p class="text-center copyright">© Copyright<br> 2020-21 Pantheon Co.<br> All rights reserved.</p>
</div>
</nav>